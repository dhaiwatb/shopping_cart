<?php 
class Master_Page
{
    protected $CI;
    public function __construct()
    {
        $this->CI =& get_instance();
    }
    //product-id: ht-1105
    //option
    /*
        qty
        price

    */
    public function layout($product_id = "",$options = array())
    {

    }
}