<?php

class Product extends FrontendController    {
    public function index()
    {
        $data['title'] = "Ecommerce - eMall";

        $this->load->view('templates/header',$data);
        $this->load->view('templates/navigation');
        $this->load->view('homepage',$data);
        $this->load->view('templates/footer');
    }
    public function product_page($title = "",$url ="",$product_data="")
    {
        $data['title'] = $title;
        $data['url'] = $url;
        $data['product_data'] =  $product_data;

        $this->load->view('templates/header',$data);
        $this->load->view('templates/navigation');
        $this->load->view('product_page',$data);
        $this->load->view('templates/footer');    
    }
    public function product_list()
    {
        $from = 0;
        $last = 4;
        $data['conjunction'] = "https://raw.githubusercontent.com/SAP/openui5/master/src/sap.ui.demokit/test/sap/ui/demokit/explored/";
        $data['all_products'] = $this->products->get_product();
        $data['cart_count'] = 0;
        $this->load->view('product_list',$data);
    }
    public function addToCart($id = "")
    {
        $data['product'] = $this->products->get_product($id);
        $item = array(
            'id' => $data['product']->ProductId,
            'qty' => 1,
            'price' => $data['product']->Price ,
            'name' => $data['product']->pName
        );
        $this->cart->insert($item);
        return redirect('product/product_list');
    }    
    public function shopping_cart()
    {
        $data['cart_items'] = $this->cart->contents();
        $this->load->view('display_cart',$data);
    }
    public function remove_item($id = "")
    {
        $id = $this->input->get('id'); 
        $this->cart->remove($id);
        return redirect('product/shopping_cart');
    }
    public function update_item()
    {
        $data = array(
            'row_id' => $this->input->post('rowid'),
            'qty' => $this->input->post('qty')
        );

        $this->cart->update($data);

        return redirect('product/shopping_cart');
    }
    public function update_cart()
    {
        $data = array(
            'rowid' => $this->input->post('rowid'),
            'qty' => $this->input->post('qty')
        );

        $this->cart->update($data);

        return redirect('product/shopping_cart');
    }
    public function check_out()
    {
        $data['cart_items'] = $this->input->post('cart_items');
        $this->load->view('cart_checkout',$data);
    }
}