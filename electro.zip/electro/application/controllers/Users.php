<?php 

class Users extends FrontendController{
    function __construct()
    {
        parent::__construct();
        $this->load->model('users_model','users');
    }
    public function index()
    {
        $data['user_list'] = array();

        $this->load->view('admin/header.php');
        $this->load->view('users/user_list',$data);
        $this->load->view('admin/footer.php');
    }
    public function user_login()
    {
        $data['user'] = array();
        $this->load->view('admin/header.php');
        $this->load->view('users/user_login',$data);
        $this->load->view('admin/footer.php');
    }
    public function user_signup()
    {
        $data['user'] = array();
        $this->load->view('admin/header.php');
        $this->load->view('users/user_signup',$data);
        $this->load->view('admin/footer.php');
    }
    public function check_signup()
    {

        if($this->form_validation->run('signup_form') == false)
        {
            $data['user'] = array();
            $this->load->view('admin/header.php');
            $this->load->view('users/user_signup',$data);
            $this->load->view('admin/footer.php');
        }
        else
        {
            $fname = $this->input->post('firstname');
            $lname = $this->input->post('lastname');
            $uname = $this->input->post('username');
            $pass = $this->input->post('password');
            $this->users->insert_user($fname,$lname,$uname,$pass);    
            return redirect('user_login');        
        }
    }
    public function check_login(){
        if($this->form_validation->run('login_form') == false)
        {
            $data['user'] = array();
            $this->load->view('admin/header.php');
            $this->load->view('users/user_login',$data);
            $this->load->view('admin/footer.php');
        }
        else
        {
            $data['username'] = $this->input->post('username');
            $data['password'] = $this->input->post('password');
            $data['userid'] = $this->users->get_username($data['username'],$data['password']);
            if($data['userid']){
                $this->session->set_userdata('username',$data['username']); 
                $this->session->set_userdata('userid',$data['userid']); 
            }
            return redirect('product/shopping_cart');
        }
    }
    public function logout()
    {
        $this->session->unset_userdata('userid');
        $this->session->unset_userdata('username');
        $this->session->sess_destroy();
        return redirect('user_login');
    }
    public function update_profile()
    {
         $data['user'] = array();
        $this->load->view('admin/header.php');
        $this->load->view('users/user_profile',$data);
        $this->load->view('admin/footer.php');
    }
}