<?php
class Products extends CI_Model{
    public function product_list($limit ="",$start="")
    {
        $q = $this->db
        ->limit($limit,$start)
        ->get('product_info');
        
        if($q->num_rows())  
        {
            return $q->result_array();
        }
        else
        {
            return false;
        }
    }
    public function getCount()
    {
        $q = $this->db->count_all('product_info');

        return $q;
    }
    public function insert_products($sku,$name,$qty,$price,$image)
    {
        $product = array(
            'ProductId'           =>  $sku,
            'pName'  =>  $name,
            'Quantity'      =>  $qty,
            'Price'         =>  $price,
            'ProductPicUrl'         =>  $image
        );

        $q = $this->db->insert('product_info',$product);
    }
    public function getCategory($mainCategory)
    {
        $q = $this->db->select('category')
        ->distinct()
        ->like("MainCategory",$mainCategory)
        ->order_by('category','ASC')
        ->get('product_info');
        $option = "<option>Select Category </option>";
        if($q->num_rows())  
        {
            //return $q->result_array();
            foreach($q->result_array() as $row):
                $option .= "<option value='".$row['category']."'>".$row['category']."</option>";
            endforeach;
            echo $option;
        }
        else
        {
            return false;
        }
    }
    public function getMainCategory()
    {
        $q = $this->db->select(['mainCategory'])
        ->distinct()
        ->order_by('mainCategory','ASC')
        ->get('product_info');

        if($q->num_rows())  
        {
            return $q->result_array();
        }
        else
        {
            return false;
        }
    }
    public function getProducts($mc,$c)
    {
        $q = $this->db->select('*')
        ->like(['MainCategory'=>$mc])
        ->or_like(['Category'=>$c])
        ->order_by('ProductId','ASC')
        ->get('product_info');
        
        $html = "";
        if($q->num_rows())  
        {
            //echo $html .= "<tr><td colspan='3'>".$q."</td></tr>";
            foreach ($q->result_array() as $value): 
                $html .= "<tr>";
                $html .= "<td class='w-25 mb-3'>".$value['ProductId']."</td>";
                $html .= "<td class='w-60 mb-3'>".$value['pName']."</td>";
                $html .= "<td class='w-15 mb-3'>";
                $html .= "<button class='btn btn primary'>Edit</button>";
                $html .= "<button class='btn btn-danger'>Delete</button>";
                $html .= "</td>";  
                $html .= "</tr>";
            endforeach;
            echo $html;
        }
        else
        {
            return false;
        }
    }
    public function get_product($id = 0)
    {
        $this->db->select('*')
        ->from('product_info');
        //echo $this->db->last_query();
        if($id)
        {                
            $q = $this->db->where('ProductId',$id)
            ->get();
            $result = $q->row();
        }            
        else
        {
            $q = $this->db->order_by('ProductId','ASC')
            ->get();
            $result = $q->result_array();
        }
        return $result;
    }    
}