<?php

class Users_model extends CI_Model{
    function __construct()
    {
        parent::__construct();        
    }
    public function insert_user($fname,$lname,$uname,$pword)
    {
        $data = array(
            'first_name'=>$fname,
            'last_name'=>$lname,
            'user_name'=>$uname,
            'uPassword'=>$pword,
            );
        $this->db
        ->set($data)
        ->insert('users');
    }
    public function get_user($id = "")
    {
        $this->db->select('*');
        if($id != null)
        {
            $this->db->where('id',$id);
        }
        $q = $this->db->from('users')
        ->get();

        if($q->num_rows() > 0)
        {
            return $q->result_array();
        }
        else
        {
            return false;
        }
    }
    public function get_username($username = "",$password="")
    {
        $q = $this->db->select('*')
        ->where('user_name',$username)
        ->where('uPassword',$password)
        ->from('users')
        ->get();

        if($q->num_rows() > 0)
        {
            return $q->row()->id;
        }
        else
        {
            return false;
        }
    }
}