<?php include('admin/header.php') ?>
<?php 
    print_r($cart_items);
?>
<?php include('admin/footer.php') ?>