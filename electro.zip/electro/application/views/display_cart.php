<?php include('admin/header.php') ?>
<div class="row">
    <div class="col-lg-12">
        <h1 id="title">Shopping cart</h1>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-8 mx-auto">
    <?php echo form_open('product/check_out', array('id'=>"myform")); ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Options</th>
                </tr>
            </thead>
                <?php if(is_array($cart_items) && count($cart_items)>0): ?>
                <?php foreach($cart_items as $item): ?>
                    <form action="<?=base_url('product/update_item');?>" method="post">
                    <tbody>
                        <tr>
                            <td><?php echo $item['id']; ?></td>
                            <td><?php echo $item['name']; ?></td>
                            <td><?php echo $item['price']; ?></td>
                            <td>
                                <input type="number" name="qty" data-rowid="<?=$item['rowid']?>" value="<?php echo $item['qty'] ?>" class="form-control update-qty" style="width: 100px !important">
                            </td>
                            <td>
                                <a href="<?php echo base_url('product/remove_item?id='.$item['rowid']); ?>" class="btn btn-warning">
                                    <i class="fa fa-trash"></i>
                                    Delete
                                </a>                                
                            </td>
                        </tr>
                    </tbody>
                    </form>
                <?php endforeach; ?>
            <?php else: ?>
                <tbody class="mx-auto">
                    <tr>
                        <td colspan="5"  >
                            <strong>
                                <p>Your cart is empty</p>
                            </strong>
                        </td>
                    </tr>
                </tbody>
            <?php endif; ?>
        </table>
        <span class="float-right">            
            <p>
                <strong>Product Total</strong>
                <i class="fa fa-eur"></i>
                <?php echo $this->cart->format_number($this->cart->total()); ?>                    
            </p>
        </span>
        
        <span class="float-left">
            <?php echo form_hidden('cart_items',$this->cart->contents());?>
            <?php echo form_submit('checkout','Checkout',array('class'=>'btn btn-primary')); ?> 
        </span>       

    <?php echo form_close();?>
    </div>
</div>
<?php include('admin/footer.php') ?>