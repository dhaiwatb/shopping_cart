<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
     <?php 
      //echo link_tag('https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css');     
      echo link_tag('https://bootswatch.com/4/journal/bootstrap.css');     
      echo link_tag('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'); 
      echo link_tag('https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css');
      echo link_tag('https://demos.creative-tim.com/datepicker/assets/css/bootstrap-datepicker.css');
      echo link_tag('https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css');
      echo link_tag(base_url('assets/css/card.css'));
    ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="<?=base_url('admin/index');?>">Electro</a>  
      <div class="collapse navbar-collapse" id="navbarColor01">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a href="<?=base_url('admin/index')?>" class="nav-link">Products' List</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('admin/product_form');?>">Insert product</a>
          </li>
          <li class="nav-item">
            <a href="<?=base_url('admin/get_filtereddata')?>" class="nav-link">Get filtered Data</a>
          </li>
          <li class="nav-item">
            <a href="<?=base_url('product/product_list')?>" class="nav-link">Shop</a>
          </li>
        </ul>
        <div class="dropdown mr-1">
          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Hello!  <?php echo $this->session->userdata('username')?$this->session->userdata('username'):"User";?>
          </button>
          <?php if($this->session->has_userdata('username')): ?>
            <div class="dropdown-menu " aria-labelledby="dropdownMenuButton">
              <a class="dropdown-item" href="<?=base_url('users/update_profile')?>">My profile</a>            
              <a class="dropdown-item" href="<?=base_url('users/logout')?>">Logout</a>
            </div>
          <?php else: ?>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <a class="dropdown-item" href="<?=base_url('users/user_login')?>">Login</a>            
              <a class="dropdown-item" href="<?=base_url('users/user_signup')?>">Register!</a>
            </div>
          <?php endif; ?>
        </div>
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="text" placeholder="Search">
          <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search <i class="fa fa-search" aria-hidden="true"></i></button>
        </form>
      </div>
    </nav>
<div class="container">