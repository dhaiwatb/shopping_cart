<?php     include('header.php');?>
<div class="col-lg-12 col-sm">
    <div class="row">
        <h1 id="title">
            <i class="fa fa-list-alt"></i>
            Product list     
        </h1>
    </div>
    <hr>
    
           
    <div class="row">
        <div class="col-lg-10  mx-auto " id="withoutfilter">
            <table class="table table-striped table-bordered" id="datatable_">
            <?php if(is_array($products) && count($products)>0): ?>
                <thead>
                    <tr>
                        <th class="th-sm">SKU</th>
                        <th class="th-sm">Product name</th>
                        <th class="th-sm">Price (in USD)</th>
                        <th class="th-sm">Update/Delete product</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach($products as $product): ?>
                    <tr>
                        <td class="w-12"><?php echo $product['ProductId'] ?></td>
                        <td class="w-50"><?php echo $product['pName'] ?></td>
                        <td class="w-18">$<?php echo $product['Price'] ?> </td>
                        <td class="w-20">
                            <button id="update_<?=$product['id']?>" class="btn btn-md py-0 btn-primary">
                            <i class="fa fa-edit">
                            </i>
                                Edit
                            </button>
                            <button id="delete_<?=$product['id']?>" class="btn btn-md py-0 btn-danger">
                            <i class="fa fa-remove">
                            </i>
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr colspan="3">
                    <td>No data available</td>
                </tr>
            <?php endif; ?>
                </tbody>
        </table>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <?php echo $this->pagination->create_links(); ?>
        </div>
    </div>
    
</div>
<?php     include('footer.php');?>