<?php include('admin/header.php') ?>
<div class="row">    
    <div class="col-lg-12 ">
        <span class="float-left">
            <h1 id="title">Buy products</h1>
        </span>
        <span class="float-right m-3">
            <a href="<?php echo base_url('product/shopping_cart') ?>">
                <i class="fa fa-cart-plus"></i> 
                <strong>
                    Cart(<?php echo $this->cart->total_items(); ?>)
                </strong>
            </a>
        </span>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 mx-auto">
        <?php //print_r($all_products); ?>
        <hr>
    </div>
</div>

<?php foreach($all_products as $item): ?>
    <div class="col-lg-6 float-left">
        <figure class="card card-product ">
            <div class="img-wrap"><img src="<?php echo $conjunction.$item['ProductPicUrl'] ?>"> 
            <a class="btn-overlay" href="#"><i class="fa fa-search-plus"></i> Quick view</a>
            </div>
            <figcaption class="info-wrap">
                <h6 class="title text-dots"><a href="#"><?php echo $item['pName'] ?></a></h6>
                <div class="action-wrap">
                    <a href="<?php echo base_url('product/addtocart/'.$item['ProductId']); ?>" class="btn btn-primary btn-md float-right"> Order </a>
                    <div class="price-wrap h5">
                        <span class="price-new"><i class="fa fa-eur" aria-hidden="true"> </i><?php echo $item['Price'] ?></span>
                    </div> <!-- price-wrap.// -->
                </div> <!-- action-wrap -->
            </figcaption>
        </figure> <!-- card // -->
    </div>
<?php endforeach; ?>

<?php include('admin/footer.php') ?>