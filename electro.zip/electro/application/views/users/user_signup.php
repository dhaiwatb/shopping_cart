<div class="col-lg-8">
    <div class="row">
        <h1 id="title">User Signup</h1>
    </div>
</div>
<hr/>
<div class="col-lg-8 mx-auto">
    <div class="row">
        
            <?php echo form_open(base_url('users/check_signup'),['name'=>'signup_form','class'=>'w-50','id'=>'user_signup']) ?>
            <div class="form-group">
                <?php echo form_label('Firstname','firstname');?>
                <?=form_input(['name'=>'firstname','class'=>'form-control','value'=>set_value('firstname')])?>
                <?php echo form_error('firstname','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group">
                <?php echo form_label('Lastname','lastname');?>
                <?=form_input(['name'=>'lastname','class'=>'form-control','value'=>set_value('lastname')])?>
                <?php echo form_error('lastname','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group">
                <?php echo form_label('Username','username');?>
                <?=form_input(['name'=>'username','class'=>'form-control','value'=>set_value('username')])?>
                <?php echo form_error('username','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group">
                <?php echo form_label('Password','password');?>                
                <?=form_password(['name'=>'password','class'=>'form-control','value'=>set_value('password')])?>
                <?php echo form_error('password','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group">
                <?php echo form_label('Confirm password','confirm-password');?>
                <?=form_password(['name'=>'confirm_password','class'=>'form-control','value'=>set_value('confirm_password')])?>
                <?php echo form_error('confirm_password','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group mt-2">
                <?=form_submit(['name'=>'submit','class'=>'btn btn-primary','value'=>'Submit'])?>
                <?=form_reset(['name'=>'reset','class'=>'btn btn-danger','value'=>'Clear','id'=>'clear'])?>
            </div>
        </form>
    </div>
</div>