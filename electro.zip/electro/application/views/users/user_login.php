<div class="col-lg-8">
    <div class="row">
        <h1 id="title">User Login</h1>
    </div>
</div>
<hr>
<div class="col-lg-10 mx-auto">
    <div class="row">
        <?php echo form_open(base_url('users/check_login'),['name'=>'login_form','class'=>'w-50','id'=>'login_form']) ?>
            <div class="form-group">
                <?php echo form_label('Username','username');?>
                <?=form_input(['name'=>'username','class'=>'form-control'])?>
                <?=form_error('username','<p class="text-danger">','</p>');?>
            </div>
            <div class="form-group">
                <?php echo form_label('Password','password');?>                
                <?=form_password(['name'=>'password','class'=>'form-control'])?>
                <?=form_error('password','<p class="text-danger">','</p>');?>
            </div>           
            <div class="form-group mt-2">
                <?=form_submit(['name'=>'submit','class'=>'btn btn-primary','value'=>'Submit','id'=>'user_login'])?>
                <?=form_reset(['name'=>'reset','class'=>'btn btn-danger ','value'=>'Clear'])?>
            </div>
        </form>
    </div>
</div>
<hr style="height:auto;width:0px;">