<div class="row">
    <div class="col-lg-12">
        <h1 id="title">User Profile</h1>
        <hr>
    </div>
</div>
<div class="row w-50 float-left m-auto">
    <div class="col">
        <h3 class="text-default">
            Delivery options
        </h3>    
        <hr>
        <?php echo form_open(base_url('users/check_userprofile'),['name'=>'user_info','class'=>'w-50','id'=>'user_info']); ?>
            <div class="form-group">
                <?=form_label('Username','username');?>
                <?=form_input(['name'=>'username','class'=>'form-control','disabled'=>'true','value'=>$this->session->userdata("username")]);?>
            </div>
            <div class="form-group">
                <?=form_label('Address 1','address_1')?>
                <?=form_input(['name'=>'address_1','class'=>'form-control']);?>
                <?=form_error('address_1','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group">
                <?=form_label('Address 2','address_2')?>
                <?=form_input(['name'=>'address_2','class'=>'form-control']);?>
                <?=form_error('address_2','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group">
                <?=form_label('State','state')?>
                <?=form_input(['name'=>'state','class'=>'form-control']);?>
                <?=form_error('state','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group">
                <?=form_label('City','city')?>
                <?=form_input(['name'=>'city','class'=>'form-control']);?>
                <?=form_error('city','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group">
                <?=form_label('Pincode','pincode')?>
                <?=form_input(['name'=>'pincode','class'=>'form-control']);?>
                <?=form_error('pincode','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group">
                <?=form_submit('submit','Submit',['class'=>'btn btn-primary'])?>
                <?=form_reset('reset','Reset',['class'=>'btn btn-default'])?>
            </div>
        <?php echo form_close();?>
    </div>
</div>
<div class="row float w-50 m-auto">
    <div class="col">
        <h3 class="text-default">
            Payment options
        </h3>    
        <hr>
        <?php echo form_open(base_url('users/check_payment'),['name'=>'payment_info','class'=>'w-50','id'=>'payment_info']); ?>
            <div class="form-group">
                <?=form_label('Credit card','credit_card')?>
                <?=form_input(['name'=>'credit_card','class'=>'form-control']);?>
                <?=form_error('credit_card','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group w-50 float-left">
                <?=form_label('Month','month')?>
                <?=form_input(['name'=>'month','class'=>'form-control w-100']);?>
                <?=form_error('month','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group w-50 float-left">
                <?=form_label('Year','year')?>
                <?=form_input(['name'=>'year','class'=>'form-control']);?>
                <?=form_error('year','<p class="text-danger">', '</p>')?>
            </div>
            <div class="form-group w-100">
                <?=form_submit('submit','Submit',['class'=>'btn btn-primary'])?>
                <?=form_reset('reset','Reset',['class'=>'btn btn-default'])?>
            </div>
        <?php echo form_close();?>
    </div>
</div>
