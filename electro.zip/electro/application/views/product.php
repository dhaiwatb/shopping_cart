<?php include('admin/header.php'); ?>

<div class="row">
    <div class="col-lg-12">
        <h1 id="title">
            <?php echo $title ?>
            <hr>
        </h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">

    </div>
</div>

<?php include('admin/footer.php'); ?>