<?php /* $this->form_validation->set_rules('firstname','First name','required');
        $this->form_validation->set_rules('lastname','Last name','required');
        $this->form_validation->set_rules('username','Username','required');
        $this->form_validation->set_rules('password','password','required');
        $this->form_validation->set_rules('confirm-password','Confirm password','required|matches[password]');*/

        $config = array(            
            'signup_form'=>array(
                array(
                    'field' => 'firstname',
                    'label' => 'First name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'lastname',
                    'label' => 'Lastname',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'username',
                    'label' => 'Username',
                    'rules' => 'required|is_unique[users.user_name]',
                    'errors' => array( 
                        'is_unique'     => 'This %s already exists.'
                    )
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'confirm_password',
                    'label' => 'Confirm Password',
                    'rules' => 'required|matches[password]'
                )
            ),
            'login_form'=>array(
                array(
                    'field' => 'username',
                    'label' => 'User name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required'
                )
            ),
            'user_info'=>array(
                array(
                    'field' => 'address_1',
                    'label' => 'Address',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'address_2',
                    'label' => 'Address',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'city',
                    'label' => 'City',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'state',
                    'label' => 'State',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'pincode',
                    'label' => 'Pincode',
                    'rules' => 'required'
                )
            )
        );