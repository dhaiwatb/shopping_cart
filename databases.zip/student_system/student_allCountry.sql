CREATE DATABASE  IF NOT EXISTS `student` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `student`;
-- MySQL dump 10.13  Distrib 5.7.26-ndb-7.6.10, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: student
-- ------------------------------------------------------
-- Server version	5.7.26-ndb-7.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allCountry`
--

DROP TABLE IF EXISTS `allCountry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allCountry` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allCountry`
--

LOCK TABLES `allCountry` WRITE;
/*!40000 ALTER TABLE `allCountry` DISABLE KEYS */;
INSERT INTO `allCountry` VALUES (1,'Afghanistan'),(2,'Albania'),(3,'Algeria'),(4,'Andorra'),(5,'Angola'),(6,'Antarctica'),(7,'Antigua and Barbuda'),(8,'Argentina'),(9,'Armenia'),(10,'Australia'),(11,'Austria'),(12,'Azerbaijan'),(13,'Bahamas'),(14,'Bahrain'),(15,'Bangladesh'),(16,'Barbados'),(17,'Belarus'),(18,'Belgium'),(19,'Belize'),(20,'Benin'),(21,'Bermuda'),(22,'Bhutan'),(23,'Bolivia'),(24,'Bosnia and Herzegovina'),(25,'Botswana'),(26,'Brazil'),(27,'Brunei'),(28,'Bulgaria'),(29,'Burkina Faso'),(30,'Burma'),(31,'Burundi'),(32,'Cambodia'),(33,'Cameroon'),(34,'Canada'),(35,'Cape Verde'),(36,'Central African Republic'),(37,'Chad'),(38,'Chile'),(39,'China'),(40,'Colombia'),(41,'Comoros'),(42,'Congo, Democratic Republic'),(43,'Congo, Republic of the'),(44,'Costa Rica'),(45,'Croatia'),(46,'Cuba'),(47,'Cyprus'),(48,'Czech Republic'),(49,'Denmark'),(50,'Djibouti'),(51,'Dominica'),(52,'Dominican Republic'),(53,'East Timor'),(54,'Ecuador'),(55,'Egypt'),(56,'El Salvador'),(57,'Equatorial Guinea'),(58,'Eritrea'),(59,'Estonia'),(60,'Ethiopia'),(61,'Fiji'),(62,'Finland'),(63,'France'),(64,'Gabon'),(65,'Gambia'),(66,'Georgia'),(67,'Germany'),(68,'Ghana'),(69,'Greece'),(70,'Greenland'),(71,'Grenada'),(72,'Guatemala'),(73,'Guinea'),(74,'Guinea-Bissau'),(75,'Guyana'),(76,'Haiti'),(77,'Honduras'),(78,'Hong Kong'),(79,'Hungary'),(80,'Iceland'),(81,'India'),(82,'Indonesia'),(83,'Iran'),(84,'Iraq'),(85,'Ireland'),(86,'Israel'),(87,'Italy'),(88,'Jamaica'),(89,'Japan'),(90,'Jordan'),(91,'Kazakhstan'),(92,'Kenya'),(93,'Kiribati'),(94,'Korea North'),(95,'Korea South'),(96,'Kuwait'),(97,'Kyrgyzstan'),(98,'Laos'),(99,'Latvia'),(100,'Lebanon'),(101,'Lesotho'),(102,'Liberia'),(103,'Libya'),(104,'Liechtenstein'),(105,'Lithuania'),(106,'Luxembourg'),(107,'Macedonia'),(108,'Madagascar'),(109,'Malawi'),(110,'Malaysia'),(111,'Maldives'),(112,'Mali'),(113,'Malta'),(114,'Marshall Islands'),(115,'Mauritania'),(116,'Mauritius'),(117,'Mexico'),(118,'Micronesia'),(119,'Moldova'),(120,'Mongolia'),(121,'Morocco'),(122,'Monaco'),(123,'Mozambique'),(124,'Namibia'),(125,'Nauru'),(126,'Nepal'),(127,'Netherlands'),(128,'New Zealand'),(129,'Nicaragua'),(130,'Niger'),(131,'Nigeria'),(132,'Norway'),(133,'Oman'),(134,'Pakistan'),(135,'Panama'),(136,'Papua New Guinea'),(137,'Paraguay'),(138,'Peru'),(139,'Philippines'),(140,'Poland'),(141,'Portugal'),(142,'Qatar'),(143,'Romania'),(144,'Russia'),(145,'Rwanda'),(146,'Samoa'),(147,'San Marino'),(148,'Sao Tome'),(149,'Saudi Arabia'),(150,'Senegal'),(151,'Serbia and Montenegro'),(152,'Seychelles'),(153,'Sierra Leone'),(154,'Singapore'),(155,'Slovakia'),(156,'Slovenia'),(157,'Solomon Islands'),(158,'Somalia'),(159,'South Africa'),(160,'Spain'),(161,'Sri Lanka'),(162,'Sudan'),(163,'Suriname'),(164,'Swaziland'),(165,'Sweden'),(166,'Switzerland'),(167,'Syria'),(168,'Taiwan'),(169,'Tajikistan'),(170,'Tanzania'),(171,'Thailand'),(172,'Togo'),(173,'Tonga'),(174,'Trinidad and Tobago'),(175,'Tunisia'),(176,'Turkey'),(177,'Turkmenistan'),(178,'Uganda'),(179,'Ukraine'),(180,'United Arab Emirates'),(181,'United Kingdom'),(182,'United States'),(183,'Uruguay'),(184,'Uzbekistan'),(185,'Vanuatu'),(186,'Venezuela'),(187,'Vietnam'),(188,'Yemen'),(189,'Zambia'),(190,'Zimbabwe');
/*!40000 ALTER TABLE `allCountry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-24 17:46:41
