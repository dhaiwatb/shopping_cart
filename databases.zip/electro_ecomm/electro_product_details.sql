CREATE DATABASE  IF NOT EXISTS `electro` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `electro`;
-- MySQL dump 10.13  Distrib 5.7.26-ndb-7.6.10, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: electro
-- ------------------------------------------------------
-- Server version	5.7.26-ndb-7.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_details`
--

DROP TABLE IF EXISTS `product_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_details` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sku` varchar(15) NOT NULL,
  `category` text NOT NULL,
  `maincategory` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_details`
--

LOCK TABLES `product_details` WRITE;
/*!40000 ALTER TABLE `product_details` DISABLE KEYS */;
INSERT INTO `product_details` VALUES (1,'HT-1000','Laptops','Computer Systems'),(2,'HT-1001','Laptops','Computer Systems'),(3,'HT-1002','Laptops','Computer Systems'),(4,'HT-1003','Laptops','Computer Systems'),(5,'HT-1007','Accessories','Computer Components'),(6,'HT-1010','Accessories','Computer Systems'),(7,'HT-1011','Laptops','Computer Systems'),(8,'HT-1020','Accessories','Computer Components'),(9,'HT-1021','Accessories','Computer Components'),(10,'HT-1022','Accessories','Computer Components'),(11,'HT-1023','Accessories','Computer Components'),(12,'HT-1030','Flat Screen Monitors','Computer Components'),(13,'HT-1031','Flat Screen Monitors','Computer Components'),(14,'HT-1032','Flat Screen Monitors','Computer Components'),(15,'HT-1035','Flat Screen Monitors','Computer Components'),(16,'HT-1036','Flat Screen Monitors','Computer Components'),(17,'HT-1037','Flat Screen Monitors','Computer Components'),(18,'HT-1040','Printers','Printers & Scanners'),(19,'HT-1041','Printers','Printers & Scanners'),(20,'HT-1042','Printers','Printers & Scanners'),(21,'HT-1050','Printers','Printers & Scanners'),(22,'HT-1051','Printers','Printers & Scanners'),(23,'HT-1052','Printers','Printers & Scanners'),(24,'HT-1055','Multifunction Printers','Printers & Scanners'),(25,'HT-1056','Multifunction Printers','Printers & Scanners'),(26,'HT-1060','Mice','Computer Components'),(27,'HT-1061','Mice','Computer Components'),(28,'HT-1062','Mice','Computer Components'),(29,'HT-1063','Keyboards','Computer Components'),(30,'HT-1064','Keyboards','Computer Components'),(31,'HT-1065','Keyboards','Computer Components'),(32,'HT-1066','Mousepads','Computer Components'),(33,'HT-1067','Mousepads','Computer Components'),(34,'HT-1068','Mousepads','Computer Components'),(35,'HT-1069','Computer System Accessories','Computer Systems'),(36,'HT-1070','Graphic Cards','Computer Components'),(37,'HT-1071','Graphic Cards','Computer Components'),(38,'HT-1072','Graphic Cards','Computer Components'),(39,'HT-1073','Graphic Cards','Computer Components'),(40,'HT-1080','Scanners','Printers & Scanners'),(41,'HT-1081','Scanners','Printers & Scanners'),(42,'HT-1082','Scanners','Printers & Scanners'),(43,'HT-1083','Scanners','Printers & Scanners'),(44,'HT-1085','Multifunction Printers','Printers & Scanners'),(45,'HT-1090','Speakers','Computer Components'),(46,'HT-1091','Speakers','Computer Components'),(47,'HT-1092','Speakers','Computer Components'),(48,'HT-1100','Software','Software'),(49,'HT-1101','Software','Software'),(50,'HT-1102','Software','Software'),(51,'HT-1103','Software','Software'),(52,'HT-1104','Software','Software'),(53,'HT-1105','Software','Software'),(54,'HT-1106','Software','Software'),(55,'HT-1107','Software','Software'),(56,'HT-1110','Computer System Accessories','Computer Systems'),(57,'HT-1111','Computer System Accessories','Computer Systems'),(58,'HT-1112','Computer System Accessories','Computer Systems'),(59,'HT-1113','Computer System Accessories','Computer Systems'),(60,'HT-1114','Computer System Accessories','Computer Systems'),(61,'HT-1115','Telecommunications','Computer Components'),(62,'HT-1116','Telecommunications','Computer Components'),(63,'HT-1117','Telecommunications','Computer Components'),(64,'HT-1118','Computer System Accessories','Computer Systems'),(65,'HT-1120','Keyboards','Computer Components'),(66,'HT-1137','Flat Screen Monitors','Computer Components'),(67,'HT-1138','Mice','Computer Components'),(68,'HT-1210','PCs','Computer Systems'),(69,'HT-1500','Servers','Computer Systems'),(70,'HT-1501','Servers','Computer Systems'),(71,'HT-1502','Servers','Computer Systems'),(72,'HT-6130','Flat Screen TVs','TV, Video & HiFi'),(73,'HT-6131','Flat Screen TVs','TV, Video & HiFi'),(74,'HT-6132','Flat Screen TVs','TV, Video & HiFi'),(75,'HT-7030','Accessories','Computer Components'),(76,'HT-7020','Accessories','Computer Components'),(77,'HT-7010','Accessories','Computer Components'),(78,'HT-7000','Accessories','Computer Components'),(79,'HT-1095','Accessories','Computer Components'),(80,'HT-1096','Accessories','Computer Components'),(81,'HT-1097','Accessories','Computer Components'),(82,'HT-6123','Accessories','TV, Video & HiFi'),(83,'HT-6122','Accessories','TV, Video & HiFi'),(84,'HT-6121','Accessories','TV, Video & HiFi'),(85,'HT-6120','Accessories','TV, Video & HiFi'),(86,'HT-6111','Accessories','TV, Video & HiFi'),(87,'HT-6110','Accessories','TV, Video & HiFi'),(88,'HT-6102','Accessories','TV, Video & HiFi'),(89,'HT-6101','Accessories','TV, Video & HiFi'),(90,'HT-2002','Accessories','TV, Video & HiFi'),(91,'HT-6100','Accessories','TV, Video & HiFi'),(92,'HT-2027','Accessories','Computer Systems'),(93,'HT-2026','Accessories','Computer Systems'),(94,'HT-2025','Accessories','Computer Systems'),(95,'HT-2001','Accessories','TV, Video & HiFi'),(96,'HT-2000','Accessories','TV, Video & HiFi'),(97,'HT-1603','Desktop Computers','Computer Systems'),(98,'HT-1602','Desktop Computers','Computer Systems'),(99,'HT-1601','Desktop Computers','Computer Systems'),(100,'HT-1600','Desktop Computers','Computer Systems'),(101,'HT-1119','Accessories','Computer Systems'),(102,'HT-8000','Laptops','Computer Systems'),(103,'HT-8001','Laptops','Computer Systems'),(104,'HT-8002','Laptops','Computer Systems'),(105,'HT-8003','Laptops','Computer Systems'),(106,'PF-1000','Accessories','Computer Systems'),(107,'HT-9999','Tablets','Smartphones & Tablets'),(108,'HT-9998','Smartphones and Tablets','Smartphones & Tablets'),(109,'HT-9997','Smartphones and Tablets','Smartphones & Tablets'),(110,'HT-9996','Accessories','Smartphones & Tablets'),(111,'HT-9995','Accessories','Smartphones & Tablets'),(112,'HT-9994','Accessories','TV, Video & HiFi'),(113,'HT-9993','Smartphones and Tablets','Smartphones & Tablets'),(114,'HT-9992','Smartphones and Tablets','Smartphones & Tablets'),(115,'HT-9991','Accessories','Smartphones & Tablets'),(116,'HT-1251','Laptops','Computer Systems'),(117,'HT-1252','Smartphones and Tablets','Smartphones & Tablets'),(118,'HT-1253','Laptops','Computer Systems'),(119,'HT-1254','Flat Screens','Computer Components'),(120,'HT-1255','Flat Screens','Computer Components'),(121,'HT-1256','Smartphones and Tablets','Smartphones & Tablets'),(122,'HT-1257','Smartphones and Tablets','Smartphones & Tablets'),(123,'HT-1258','Smartphones and Tablets','Smartphones & Tablets');
/*!40000 ALTER TABLE `product_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-24 17:46:40
